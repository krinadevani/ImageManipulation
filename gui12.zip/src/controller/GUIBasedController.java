package controller;

import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.io.OutputStream;

import features.Features;
import model.EnhancedModelInterface;
import view.ImageView;
import view.JFrameView;

/**
 * A GUI based controlled to support delegation of task to the graphical
 * user interface.
 */
public class GUIBasedController extends EnhanceController implements Features {

  private final static String currImgName = "CurrentImage";
  private final static String redCurrImgName = "RedCurrentImage";
  private final static String greenCurrImgName = "GreenCurrentImage";
  private final static String blueCurrImgName = "BlueCurrentImage";
  private final EnhancedModelInterface model2;
  private JFrameView jFrameview;

  /**
   * Given constructor will initialize model, view and
   * input output stream.
   *
   * @param model the model provided
   * @param view  the view provided
   * @param in    the input stream
   * @param out   the output stream
   */
  public GUIBasedController(EnhancedModelInterface model,
                            ImageView view, InputStream in, OutputStream out) {
    super(model, view, in, out);
    this.model2 = model;
  }

  @Override
  public void setView(JFrameView view) {
    this.jFrameview = view;
    jFrameview.addFeatures(this);
  }


  @Override
  public void loadImage(String imagePath) {
    if (!imagePath.equals("")) {
      processCommand("load " + imagePath + " " + currImgName);
      refreshImage();
    }
  }

  @Override
  public void saveImage(String imgPath, String imageName) {
    if (!imgPath.equals("")) {
      if (imageName.equals("")) {
        imageName = currImgName;
      }
      processCommand("save " + imgPath + " " + imageName);
    }
  }

  @Override
  public void manipulateImage(String cmd) {
    processCommand(cmd + " "
            + currImgName + " " + currImgName);
    refreshImage();
  }

  @Override
  public void splitImage(String redPath, String greenPath, String bluePath) {
    processCommand("rgb-split "
            + currImgName + " " + redCurrImgName
            + " " + greenCurrImgName + " " + blueCurrImgName);
    saveImage(redPath, redCurrImgName);
    saveImage(greenPath, greenCurrImgName);
    saveImage(bluePath, blueCurrImgName);
  }

  @Override
  public void combineImage(String redPath, String greenPath, String bluePath) {
    processCommand("load " + redPath + " " + redCurrImgName);
    processCommand("load " + greenPath + " " + greenCurrImgName);
    processCommand("load " + bluePath + " " + blueCurrImgName);
    processCommand("rgb-combine "
            + currImgName + " " + redCurrImgName
            + " " + greenCurrImgName + " "
            + blueCurrImgName);
    refreshImage();
  }

  // helper method to refresh the image
  private void refreshImage() {
    BufferedImage image = model2.getCurrentImage(currImgName);
    jFrameview.refreshImage(image);
    plotHistogram();
  }

  @Override
  public void plotHistogram() {
    //call model to return the processed histogram data
    DefaultCategoryDataset dataset = model2.histogram(currImgName);
    // pass this data to the view to display
    jFrameview.refreshHistogram(dataset);
  }
}
